registerWorld({
  id: 'ej', n: 0, title: 'Ejemplo', subtitle: 'Mundo de muestra', emoji: '🧪', color: '#8b5cf6',
  intro: 'Mundo de ejemplo para copiar el formato.',
  badge: { name: 'Ejemplo', emoji: '🧪' },
  lessons: [{
    id: 'ej-l1', title: 'Calcular el precio de unos cuadernos', emoji: '📓', minutes: 6,
    learn: [
      { title: 'Entrada, proceso y salida', blocks: [
        { t: 'p', text: 'Todo programa hace tres cosas: **recibe datos** (entrada), **hace cálculos** (proceso) y **muestra un resultado** (salida).' },
        { t: 'analogy', text: 'Es como pagar en la tienda: entregas el dinero (entrada), la tendera hace la cuenta (proceso) y te da el vuelto (salida).' },
        { t: 'table', head: ['Parte', 'En la tienda', 'En el programa'], rows: [['Entrada', 'precio y cantidad', 'precio, cantidad'], ['Proceso', 'multiplicar', 'precio * cantidad'], ['Salida', 'el total', 'print(total)']] },
      ] },
      { title: 'Guardar datos en variables', blocks: [
        { t: 'p', text: 'Una **variable** es una cajita con nombre donde guardas un dato. Por ejemplo, `precio = 4500` guarda el número 4500 en la caja `precio`.' },
        { t: 'code', lang: 'python', code: 'precio = 4500\ncantidad = 3\ntotal = precio * cantidad\nprint(total)', run: true },
        { t: 'tip', text: 'El signo `=` no significa "igual a": significa "guarda en".' },
      ] },
      { title: 'Cómo se ve en un diagrama', blocks: [
        { t: 'flow', steps: [{ shape: 'start', text: 'Inicio' }, { shape: 'io', text: 'Leer precio y cantidad' }, { shape: 'process', text: 'total = precio × cantidad' }, { shape: 'io', text: 'Mostrar total' }, { shape: 'end', text: 'Fin' }] },
        { t: 'warn', text: 'Si escribes `precio + cantidad` en vez de `precio * cantidad`, el programa corre pero da un resultado equivocado.' },
      ] },
    ],
    example: {
      title: 'Comprar cuadernos',
      story: 'Camila compra 3 cuadernos de $4.500 cada uno. Quiere saber cuánto pagará en total.',
      pseudo: 'INICIO\n  LEER precio\n  LEER cantidad\n  total = precio * cantidad\n  MOSTRAR total\nFIN',
      code: { lang: 'python', code: 'precio = int(input())\ncantidad = int(input())\ntotal = precio * cantidad\nprint(total)', run: true, inputs: '4500\n3' },
      note: 'Cambia las entradas de abajo y vuelve a ejecutar: el proceso es el mismo.',
    },
    practice: [
      { type: 'mcq', q: 'En el problema de los cuadernos, ¿cuál es la SALIDA?', options: ['El precio de un cuaderno', 'La cantidad de cuadernos', 'El total a pagar'], answer: 2,
        wrong: { 0: 'El precio es un dato que recibimos: es una entrada.', 1: 'La cantidad también se recibe al inicio: es una entrada.' }, explain: 'La salida es lo que el programa entrega al final: el total a pagar.', hints: ['La salida es lo que se muestra al final.'] },
      { type: 'input', q: 'Si compras 4 cuadernos de $4.500, ¿cuánto pagas en total?', answers: ['18000'], common: [{ re: '^9[.,]?000$', msg: 'Sumaste 4.500 + 4.500. Hay 4 cuadernos: multiplica 4.500 × 4.' }], explain: '4500 × 4 = 18000.', hints: ['Es una multiplicación: precio × cantidad.'] },
      { type: 'order', q: 'Ordena los pasos del algoritmo:', items: ['Leer el precio', 'Leer la cantidad', 'Multiplicar precio por cantidad', 'Mostrar el total'], explain: 'Primero se piden los datos, luego se calcula y al final se muestra.' },
    ],
    challenge: { type: 'code', lang: 'python', q: '🎯 Misión: escribe un programa que lea el precio y la cantidad (con input) y muestre el total.', starter: 'precio = int(input())\n',
      tests: [{ inputs: ['4500', '3'], output: '13500' }, { inputs: ['1200', '10'], output: '12000' }, { inputs: ['0', '5'], output: '0' }],
      checks: [{ re: 'print', msg: 'Recuerda mostrar el resultado con print().' }],
      solution: 'precio = int(input())\ncantidad = int(input())\nprint(precio * cantidad)', hints: ['Necesitas un segundo input() para la cantidad.', 'total = precio * cantidad'], explain: 'Se leen dos datos, se multiplican y se muestra el resultado con print().' },
    summary: ['Un programa tiene entrada, proceso y salida.', 'Una variable guarda un dato con un nombre.', 'El total es precio × cantidad.'],
  }],
  exam: [],
});
