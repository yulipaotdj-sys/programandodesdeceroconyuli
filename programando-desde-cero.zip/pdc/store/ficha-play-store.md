# Ficha de Google Play — copiar y pegar

**Nombre de la app (máx. 30):** Programando desde Cero

**Descripción breve (máx. 80):**
Aprende a programar desde cero jugando: mundos, XP, insignias y certificado.

**Descripción completa (máx. 4000):**
¿Quieres aprender a programar pero no sabes por dónde empezar? Con *Programando desde Cero con Yuli* avanzas como en un videojuego: superas niveles, ganas puntos de experiencia (XP), monedas e insignias y, al final, recibes un certificado de finalización.

🎮 APRENDE JUGANDO
• 7 mundos con candados que se desbloquean: lógica, Python, resolución de problemas, desarrollo web, bases de datos, ingeniería de software y proyectos propios.
• Más de 80 lecciones cortas: Aprende → Ejemplo → Practica → Reto final → Recompensa.
• Ejercicios que se califican de verdad: escribe código y la app lo ejecuta y te explica qué estuvo bien y qué corregir. Nunca te da la respuesta de inmediato: primero pistas.
• Exámenes por mundo: necesitas 70 % para avanzar y te recomendamos qué repasar.

🔥 DIVERTIDA Y ADICTIVA (EN EL BUEN SENTIDO)
• Rachas diarias, misiones del día, cofres, retos sorpresa y combos.
• 6 rangos: de Exploradora del código a Desarrolladora de software.
• Repaso inteligente de tus errores.

🌎 INGLÉS PARA PROGRAMADORES
Vocabulario, mensajes de error, Git, README, Scrum, entrevistas y correos, con audio para practicar la pronunciación.

☁️ TU PROGRESO, SEGURO EN TU DRIVE
Guarda tu avance en una carpeta oculta de tu propio Google Drive: cambia de celular sin perder nada. La app no puede ver ningún otro archivo de tu Drive.

🧑‍💻 TALLER DE CÓDIGO
Prueba Python, JavaScript y HTML sin instalar nada.

La app es gratis y se financia con anuncios. Funciona sin conexión.
El certificado es un reconocimiento de finalización emitido por la app; no es un título oficial.

**Categoría:** Educación · **Etiquetas:** Educación, programación
**Contacto:** tu correo · **Política de privacidad:** URL pública de `legal/privacidad.html`

## Seguridad de los datos (guía para el formulario)
- ¿Recopila o comparte datos? **Sí.**
- **Información personal → Nombre / Dirección de correo**: solo si inicia sesión con Google para el Drive. *Recopilado*: sí (opcional). *Compartido*: no. Finalidad: funcionalidad de la app. Cifrado en tránsito: sí. El usuario puede pedir eliminación: sí (Perfil → Desconectar Drive / Borrar progreso).
- **Actividad en la app / Otro contenido generado por el usuario** (progreso): se guarda en el dispositivo y en el Drive del usuario (no en servidores propios).
- **Identificadores de dispositivo o de otro tipo** y **Ubicación aproximada**, **Interacciones con anuncios**: recopilados y compartidos con **Google AdMob** (publicidad o marketing, análisis, prevención de fraude). 
- ¿Datos cifrados en tránsito? Sí. ¿Pueden eliminar sus datos? Sí.
(Revisa tu formulario con lo que declare el SDK de AdMob vigente en la documentación de Google.)

## Clasificación de contenido
Cuestionario IARC: sin violencia, sin contenido sexual, sin juegos de azar, sin compras reales, sin interacción entre usuarios, sin compartir ubicación. Resultado esperado: apta para todo público. **Público objetivo:** 13+.

## Notas de la versión 1.0
Primera versión: 7 mundos + mundo extra de inglés, Taller de código, misiones diarias, certificado y copia del progreso en Google Drive.
