# Programando desde Cero con Yuli — Mi aventura como desarrolladora

App educativa gamificada (HTML + CSS + JavaScript, sin servidores): **7 mundos + Mundo extra de inglés**, 81 lecciones, ejercicios que se califican de verdad (ejecuta Python, JavaScript, SQL y HTML/CSS dentro de la app), exámenes con 70 % para aprobar, XP, monedas, insignias, rangos, rachas, misiones diarias, cofres, retos sorpresa, repaso de errores, Taller de código y certificado en PDF.

Se publica en Play Store empaquetada con **Capacitor** (anuncios reales de AdMob + inicio de sesión de Google para el Drive).

## 1. Probar ahora mismo
- `dist/preview.html` → ábrelo en el navegador (un solo archivo; anuncios simulados; Drive desactivado).
- O con servidor: `cd` a esta carpeta y `python3 -m http.server 8000` → http://localhost:8000

## 2. Configurar tus datos — `config.js`
| Campo | Qué poner |
|---|---|
| `contactEmail` | Tu correo público de contacto (aparece en Privacidad, Términos y Contacto) |
| `privacyUrl` | URL pública de `legal/privacidad.html` (ver paso 5) |
| `googleClientId` | ID de cliente **Web** de Google (paso 3) |
| `admob.*` | Tus IDs de AdMob (paso 4). Los que trae son de **prueba** de Google. `testing:false` al publicar |
| `webFakeAds` | `true` = anuncios simulados en la web; `false` = sin anuncios en la web |

Luego ejecuta `node tools/build.js` (regenera `legal/*.html`, `www/` y `dist/preview.html`).
Cambia también `serverClientId` en `capacitor.config.json`.

## 3. Guardar el progreso en el Drive de cada usuaria
La app guarda un JSON en la **carpeta oculta de la app** (`appDataFolder`) del Drive de cada persona. Solo pide el permiso `drive.appdata`: no puede ver ningún otro archivo. Se sincroniza sola (al estudiar, al cerrar, al volver la conexión) y combina el avance de varios dispositivos sin perder nada.
1. https://console.cloud.google.com → crea un proyecto → **APIs y servicios → Biblioteca → Google Drive API → Habilitar**.
2. **Pantalla de consentimiento OAuth**: tipo Externo, nombre de la app, correo, enlaces a tu política y términos; agrega el alcance `.../auth/drive.appdata` (es un alcance *no sensible*, no requiere verificación pesada). Pásala a **En producción** cuando publiques.
3. **Credenciales → ID de cliente OAuth**:
   - tipo **Aplicación web** → ese ID va en `googleClientId` y en `serverClientId`. En "Orígenes autorizados" agrega la URL donde alojes la versión web (si la usas).
   - tipo **Android** → paquete `co.yulipao.programandodesdecero` + huella **SHA-1** de tu llave de firma (y la de *Play App Signing* cuando subas a Play).

## 4. Anuncios gratis con AdMob
1. https://admob.google.com → agrega la app Android → copia el **App ID** (`ca-app-pub-xxx~yyy`).
2. Crea 3 bloques: **Banner**, **Intersticial**, **Con recompensa** → pega sus IDs en `config.js` (`admob`) y pon `testing: false`.
3. En `android/app/src/main/AndroidManifest.xml`, dentro de `<application>`:
   ```xml
   <meta-data android:name="com.google.android.gms.ads.APPLICATION_ID" android:value="ca-app-pub-xxx~yyy"/>
   ```
4. Cómo se muestran (para no molestar al estudiar): banner abajo solo en mapa/perfil/misiones (nunca durante una lección ni examen); pantalla completa solo entre lecciones, 1 cada 3 lecciones y nunca más seguido que cada 4 min; el anuncio con recompensa es **voluntario** (duplicar cofre, recuperar racha). Se ajusta en `config.js`.
5. El formulario de consentimiento (UMP) sale automáticamente donde la ley lo exige.

## 5. Políticas y contacto
Dentro de la app: Perfil → Política de privacidad / Términos / Contacto (y pantalla de bienvenida). Para Play Console necesitas una **URL pública**: sube la carpeta `legal/` a GitHub Pages (o cualquier hosting) y usa `…/legal/privacidad.html`. Los textos están en `js/legal.js` (revísalos y, si puedes, que los vea alguien con conocimiento legal).

## 6. Generar la app de Android (AAB)
Requisitos: Node 18+, Android Studio.
```bash
npm install
npm run build
npx cap add android       # solo la primera vez
npx cap sync android
npx cap open android      # Android Studio: agrega el meta-data de AdMob (paso 4) y compila
```
En Android Studio: **Build → Generate Signed Bundle (AAB)**, crea tu llave (guárdala bien) y sube el `.aab` a Play Console. Íconos: usa `icons/` y `store/icon-1024.png`.
Cada vez que cambies algo: `npm run android:sync`.

## 7. Play Console (resumen)
- Ficha: textos listos en `store/ficha-play-store.md`; ícono 512 (`icons/icon-512.png`), gráfico de funciones `store/feature-graphic-1024x500.png`, capturas en `store/screenshots/`.
- **Política de privacidad**: la URL del paso 5.
- **Anuncios**: marca "Sí, contiene anuncios".
- **Seguridad de los datos**: guía en `store/ficha-play-store.md`.
- **Público objetivo**: 13 años o más (no "Familias").
- Si tu cuenta de desarrollador es personal y nueva, Google exige una **prueba cerrada con testers durante 14 días** antes de producción (verifica el número actual en la ayuda de Play Console).

## 8. Agregar o cambiar lecciones
Cada mundo es un archivo en `content/` (formato en `tools/SCHEMA.md`). Después de editar: `npm run validate` — **ejecuta las soluciones** de todos los ejercicios con el mismo motor de la app y avisa si algo no pasa. Para un mundo nuevo, agrega su `<script>` en `index.html` y en `tools/build.js`/`sw.js` (o re-ejecuta el build y regenera `sw.js`).

## 9. Qué se probó y qué no
Probado en navegador (Chromium móvil): bienvenida, 3 lecciones jugadas completas con respuestas reales, los 8 exámenes (100 %), Taller, misiones, perfil, certificado PDF/PNG y vista previa de un archivo. Validadas las 81 lecciones (≈400 ejercicios ejecutados).
**No se pudo probar aquí** (necesita tus cuentas/dispositivo): compilación Android, anuncios reales de AdMob, inicio de sesión de Google y sincronización con Drive real. Si al hacer `npm install` alguna versión de plugin cambia, ajusta `package.json` (se usan los plugins compatibles con Capacitor 6).
