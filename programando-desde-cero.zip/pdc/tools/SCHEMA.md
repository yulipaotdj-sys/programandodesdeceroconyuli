# Guía para escribir contenido — "Programando desde Cero con Yuli"

La app es un videojuego educativo en **español** para **Yuli y otras estudiantes que empiezan desde cero** (Tecnólogo en Análisis y Desarrollo de Software, SENA). Cada **mundo** es un archivo `content/<archivo>.js` que llama a `registerWorld({...})`.

Valida SIEMPRE con: `cd /home/claude/pdc && node tools/validate.js content/<archivo>.js`
El validador **ejecuta tus soluciones** (Python, JS, SQL, HTML/CSS) y falla si alguna no pasa. Corrige hasta ver `✅ Contenido válido.` y revisa también los AVISOS.
Un ejemplo completo y válido está en `content/_ejemplo.js` (cópialo como punto de partida; valida con `--example`).

## Voz y pedagogía (muy importante)
- Español sencillo, cálido, sin jerga. Trata a la estudiante de "tú". Usa femenino cuando hables de la estudiante/desarrolladora ("estás aprendiendo", "ya eres capaz"). Nada de tono infantil.
- **Analogías de la vida cotidiana** colombiana: tienda de barrio, buses, recibos, notas del SENA, arepas, recargas a celular, pesos COP ($4.500), etc.
- Cada término técnico nuevo se explica la primera vez que aparece ("**variable**: una cajita con nombre donde guardas un dato").
- Frases cortas (≤ 20 palabras). Nada de párrafos largos: una idea por bloque.
- Explica el error con paciencia: en `explain` y en `wrong`/`common` di QUÉ falló y CÓMO corregirlo, no solo "incorrecto".
- Contenido educativo REAL y correcto. Sin relleno, sin ejercicios repetidos, sin respuestas ambiguas (si hay dos respuestas posibles, acéptalas ambas).
- Progresión: de lo fácil a lo difícil dentro del mundo; cada lección usa lo de las anteriores.

## Estructura de un mundo
```js
registerWorld({
  id: 'm1',                       // m1..m7 o 'en'
  n: 1,                           // número de mundo (inglés: 8)
  title: 'Pensamiento lógico y fundamentos',
  subtitle: 'Aprende a pensar como programadora',
  emoji: '🧠', color: '#8b5cf6',  // color del mundo (hex)
  intro: 'Texto de bienvenida al mundo (2–3 frases).',
  badge: { name: 'Mente lógica', emoji: '🧠' },   // insignia al aprobar el examen
  lessons: [ /* ver abajo */ ],
  exam: [ /* 8–10 preguntas, ver abajo */ ],
});
```
Los `id` de lección: `<mundo>-l1`, `<mundo>-l2`, … (p. ej. `m1-l1`).

## Estructura de una lección (6 pasos del método)
```js
{
  id: 'm1-l1', title: '¿Qué significa programar?', emoji: '🧠', minutes: 6,
  learn: [                         // 1. APRENDE — 3 o 4 tarjetas, cada una con 2–5 bloques
    { title: 'Una receta para el computador', blocks: [
      { t: 'p', text: 'Texto. Soporta **negrita**, *cursiva* y `código en línea`.' },
      { t: 'analogy', text: 'Es como una receta de cocina…' },
      { t: 'list', items: ['uno', 'dos'] },
      { t: 'steps', items: ['Primero…', 'Luego…'] },        // lista numerada
      { t: 'tip', text: 'Consejo útil.' },
      { t: 'warn', text: 'Error común: …' },
      { t: 'code', lang: 'python', code: 'print("Hola")', run: true },  // run:true => botón ▶ Ejecutar (solo python/js/html)
      { t: 'table', head: ['Variable', 'Valor'], rows: [['edad', '25'], ['nombre', '"Ana"']] },
      { t: 'vocab', items: [{ en: 'variable', es: 'variable: cajita con nombre que guarda un dato', ex: 'The variable stores the user name.' }] },   // vocabulario con botón 🔊 (voz en inglés)
      { t: 'dialog', lines: [{ who: 'Ana', en: 'What did you do yesterday?', es: '¿Qué hiciste ayer?' }] },   // conversación inglés + traducción (con 🔊)
      { t: 'flow', steps: [                                  // diagrama de flujo simple
          { shape: 'start', text: 'Inicio' }, { shape: 'io', text: 'Leer precio' },
          { shape: 'process', text: 'total = precio × cantidad' },
          { shape: 'decision', text: '¿total > 10000?', yes: 'Aplicar descuento', no: 'Seguir' },
          { shape: 'end', text: 'Fin' } ] },
    ]},
  ],
  example: {                       // 2. EJEMPLO
    title: 'Comprar cuadernos',
    story: 'Situación cotidiana en 2–4 frases.',
    pseudo: 'INICIO\n  LEER precio\n  …\nFIN',                 // opcional (texto)
    code: { lang: 'python', code: 'precio = 4500\nprint(precio)', run: true, inputs: '' },  // opcional; inputs = valores de input() uno por línea
    note: 'Qué observar en el ejemplo.',                      // opcional
  },
  practice: [ /* 3. PRACTICA + 4. COMPRUEBA — 3 ejercicios de tipos VARIADOS */ ],
  challenge: { /* 5. RETO FINAL — 1 ejercicio, un poco más difícil. Su q debe empezar con "🎯 Misión: " */ },
  summary: ['Lo que aprendiste 1', 'Lo que aprendiste 2', 'Lo que aprendiste 3'],   // ≥3 viñetas
}
```
Cada lección: 3–4 tarjetas de aprendizaje (≈150–300 palabras en total), 1 ejemplo, 3 ejercicios de práctica, 1 reto. La app da XP según desempeño; tú no pones XP.

## Tipos de ejercicio (todos requieren `q` y `explain`; casi todos aceptan `hints`)
Cualquier ejercicio acepta además `say: 'English sentence'`: muestra un botón 🔊 que la app lee en voz alta en inglés (para ejercicios de escucha, p. ej. `q: 'Escucha y elige lo que dice la persona'`, `say: 'Push your changes to the main branch'`).
`hints`: arreglo de 1–3 pistas progresivas (de la más sutil a la más directa; **nunca** la respuesta completa).

```js
// Selección múltiple (3–5 opciones, UNA correcta). wrong = explicación específica por opción incorrecta (muy recomendado)
{ type: 'mcq', q: '¿Qué es un algoritmo?', options: ['…', '…', '…'], answer: 1,
  wrong: { 0: 'Eso describe…, pero…', 2: '…' }, explain: 'Porque…', hints: ['…'] }

// Verdadero/falso
{ type: 'tf', q: 'Una variable puede cambiar de valor.', answer: true, explain: '…' }

// Varias correctas (≥2 de ≥4 opciones)
{ type: 'multi', q: 'Marca TODOS los tipos de datos:', options: ['…'], answers: [0, 2], explain: '…' }

// Respuesta corta escrita. answers = todas las formas aceptadas (la app ignora mayúsculas, tildes, espacios, "$" y separadores de miles: "4.500" = "4500").
// common = errores frecuentes: si la respuesta del estudiante coincide con la regex, se muestra msg.
{ type: 'input', q: '3 cuadernos a $4.500 cada uno. ¿Cuánto es el total?', answers: ['13500'],
  common: [{ re: '^1[.,]?500$', msg: 'Parece que sumaste… recuerda que es una multiplicación.' }],
  table: { head: ['Dato', 'Valor'], rows: [['precio', '4500']] },   // opcional: tabla mostrada bajo el enunciado
  explain: '4500 × 3 = 13500', hints: ['…'] }

// Ordenar pasos: items en el orden CORRECTO (la app los mezcla). 3–8 items.
{ type: 'order', q: 'Ordena los pasos para preparar un tinto:', items: ['Hervir el agua', '…', '…'], explain: '…' }

// Completar (huecos "___" en template, uno por blank). Un blank con options = menú de opciones; sin options = campo de texto.
{ type: 'fill', q: 'Completa el algoritmo:', template: 'total = precio ___ cantidad\nprint(___)',
  blanks: [{ answers: ['*'], options: ['+', '*', '-'] }, { answers: ['total'] }], explain: '…' }

// Relacionar (3–6 pares [izquierda, derecha]; la app mezcla la derecha)
{ type: 'match', q: 'Une cada concepto con su significado:', pairs: [['Entrada', 'Los datos que recibe'], ['Proceso', '…'], ['Salida', '…']], explain: '…' }

// Encontrar el error: code = varias líneas; bugLine = número de línea (empieza en 1) donde está el error
{ type: 'bug', q: 'Toca la línea que tiene el error:', code: 'edad = 20\nprint(Edad)\nprint("fin")', bugLine: 2, explain: '…' }

// Escribir código (ver abajo)
{ type: 'code', lang: 'python', … }
```

### Ejercicios `code`
Campos comunes: `lang` (`python`|`js`|`html`|`css`|`sql`|`pseudo`), `q`, `starter` (código inicial; puede ser `''`, **no debe ya pasar**), `solution` (el validador la ejecuta), `hints`, `explain`, `checks`, `common`.
- `checks`: `[{ re: 'for\\s+\\w+\\s+in', msg: 'Usa un ciclo for' }]` — regex (insensible a mayúsculas) sobre el TEXTO del código. `not: true` invierte (no debe aparecer). Útil para forzar una técnica ("usa un for").
- `common`: `[{ re, msg }]` mensajes para errores típicos.

**python** y **js**: `tests: [{ inputs: ['5', '3'], output: '8' }, …]` — `inputs` alimentan `input()` (python) o `prompt()` (js) en orden; `output` es lo que debe imprimir el programa (se ignoran espacios al final de cada línea y líneas vacías al inicio/fin). Si el programa usa `input("texto")`, el texto del prompt **sale en la salida** (sin salto de línea). Para no depender de textos libres usa `contains: ['13500']` (todas las cadenas deben aparecer, sin importar mayúsculas/tildes) en vez de `output`. Pon ≥2 tests con datos distintos (incluye un caso borde). Un test puede llevar `hidden: true`.
 ⚠ **Python soportado** (simulador propio): print(sep,end), input, int/float/str/bool/list/tuple/dict, len, range, abs, round, min, max, sum, sorted, reversed, enumerate, zip, map, filter, any, all, type, isinstance, chr/ord, divmod, pow, bin/hex; if/elif/else, for, while, break/continue/pass, def/return/lambda, try/except/finally, global, listas por comprensión, f-strings con formato (`{x:.2f}`, `{n:,}`, `{s:>8}`), `%` y `.format()`, métodos de str/list/dict/tuple, `import math`, `import random`. **NO soportado**: clases (`class`), `with`, `open()`, sets `{1,2}`, `**kwargs`, `yield`, módulos distintos de math/random, `datetime`, `os`, `sys`. Evita aleatoriedad en ejercicios con `tests` (la salida debe ser determinista).
 ⚠ **JS** (`lang:'js'`): solo consola — `console.log`, `prompt()` (devuelve string). Sin DOM. Para DOM usa `lang:'html'`.

**html**: el estudiante escribe el cuerpo de la página (o una página completa; si incluye `<html>`/`<!doctype` se usa tal cual; puede incluir `<style>` y `<script>`). Se califica con `domChecks` sobre el documento resultante:
```js
{ type: 'code', lang: 'html', q: 'Crea un título h1 que diga "Mi página" y un botón.', starter: '<!-- escribe aquí -->',
  domChecks: [ { sel: 'h1', text: 'mi p[aá]gina', msg: 'Falta el <h1> con el texto "Mi página".' },
               { sel: 'button', count: 1, msg: 'Agrega exactamente un botón.' } ],
  solution: '<h1>Mi página</h1><button>Hola</button>', hints: ['…'], explain: '…' }
```
`domChecks` admite por elemento: `sel` (selector CSS), `count` (exacto) | `min` | `exists:false`, `text` (regex sobre el textContent), `css: {propiedad: valor}` (estilo calculado), `attr: {nombre: regex|true}`, `value`, y `msg`. Para JS+DOM usa `actions: [{ click: '#btn' }, { type: '#nombre', value: 'Ana' }]`, que se ejecutan ANTES de revisar `domChecks` (así calificas eventos: "al hacer clic, el párrafo #msg debe decir …").

**css**: igual que html, pero además lleva `html` (el marcado fijo) y el estudiante escribe SOLO el CSS:
```js
{ type: 'code', lang: 'css', html: '<h1 id="t">Hola</h1><p class="nota">Texto</p>', q: 'Pon el h1 en rojo y el párrafo en 20px.',
  starter: 'h1 {\n  \n}', domChecks: [ { sel: '#t', css: { color: 'red' } }, { sel: '.nota', css: { 'font-size': '20px' } } ],
  solution: 'h1{color:red} .nota{font-size:20px}', explain: '…' }
```

**sql**: lleva `db` (tablas de práctica) y el resultado esperado:
```js
{ type: 'code', lang: 'sql', q: 'Muestra el nombre de las estudiantes mayores de edad.',
  db: { estudiantes: { cols: ['id', 'nombre', 'edad'], rows: [[1, 'Ana', 20], [2, 'Luis', 17]] } },
  expect: { rows: [['Ana']], ordered: false /* true si importa el orden */ },       // para SELECT
  // para INSERT/UPDATE/DELETE: expectTable: { name: 'estudiantes', rows: [[...]], ordered: false }
  starter: 'SELECT ', solution: "SELECT nombre FROM estudiantes WHERE edad >= 18", explain: '…', hints: ['…'] }
```
SQL soportado: SELECT [DISTINCT] (cols, *, alias AS, COUNT/SUM/AVG/MIN/MAX, UPPER/LOWER/LENGTH/ROUND), FROM, [INNER|LEFT] JOIN … ON, WHERE (=, <>, <, >, <=, >=, AND, OR, NOT, LIKE, IN, BETWEEN, IS [NOT] NULL), GROUP BY, HAVING, ORDER BY (ASC/DESC), LIMIT/OFFSET, INSERT INTO … VALUES, UPDATE … SET … WHERE, DELETE FROM … WHERE, CREATE TABLE (solo nombres de columna). Varias sentencias separadas por `;` (el resultado del último SELECT es el que se compara). Las tablas de `db` pueden ser varias. El `expect` se compara contra lo que devuelve la solución: el validador lo comprueba.

**pseudo** (pseudocódigo): se califica solo con `checks` (≥2 regex), p. ej. que contenga `leer`, `mostrar|escribir|imprimir`, `\*|multiplic`, y `minLines: 4` (opcional). Redacta checks tolerantes a sinónimos (`'leer|lea|ingresar|entrada'`).

## Examen del mundo
`exam`: 8–10 preguntas mezcladas (mcq, tf, input, order, fill, match, bug, multi; máx. 2 `code`). Cada una lleva **`lesson: '<id de lección del mundo>'`** (se usa para recomendar repaso si saca < 70 %) y `explain` (se muestra al terminar). Cubre TODAS las lecciones del mundo. No repitas literalmente los ejercicios de práctica.

## Reglas de calidad (revisión final)
1. Cada lección tiene ≥3 tipos distintos de ejercicio en total entre práctica y reto.
2. En `mcq`: opciones plausibles, una sola correcta, `wrong` para las incorrectas más tentadoras.
3. Nada de "Todas las anteriores" ni "Ninguna de las anteriores".
4. Las `answers` de `input` incluyen variantes razonables ("13500", "13.500" no hace falta: la app ya normaliza separadores).
5. El código de ejemplo y de las soluciones debe ser correcto, claro y con nombres de variables en español sin tildes ni ñ (`precio`, `cantidad`, `anio`) salvo donde la lección diga otra cosa.
6. Usa pesos colombianos y contextos locales; sin marcas registradas ni personas reales.
7. Archivo JS válido (comillas bien escapadas; usa backticks para textos largos con saltos de línea). Sin dependencias externas.
