#!/usr/bin/env node
/* Genera: legal/*.html (páginas públicas), www/ (para Capacitor/web) y dist/preview.html (un solo archivo para probar). */
const fs = require('fs'), path = require('path'), vm = require('vm');
const ROOT = path.join(__dirname, '..'); const rd = f => fs.readFileSync(path.join(ROOT, f), 'utf8');
const ctx = { window: {} }; vm.createContext(ctx); vm.runInContext(rd('config.js'), ctx); const CFG = ctx.window.PDC_CONFIG;
globalThis.PDC_CONFIG = CFG; const Legal = require(path.join(ROOT, 'js/legal.js'));
/* 1. Páginas legales estáticas */
const css = 'body{font-family:system-ui,Segoe UI,Roboto,sans-serif;max-width:760px;margin:0 auto;padding:20px 18px 60px;line-height:1.6;color:#1b1f4b;background:#f6f4ff}h1{color:#6d3df0}h2{margin-top:1.6em;font-size:1.2rem}a{color:#6d3df0}.muted{color:#6b6f93}nav{margin:0 0 24px;display:flex;gap:14px;flex-wrap:wrap;font-weight:700}code{background:#ece8ff;padding:1px 5px;border-radius:5px}';
fs.mkdirSync(path.join(ROOT, 'legal'), { recursive: true });
const pages = { privacidad: 'Política de privacidad', terminos: 'Términos de uso', contacto: 'Contacto' };
for (const k in pages) fs.writeFileSync(path.join(ROOT, 'legal', k + '.html'), `<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${pages[k]} — ${CFG.appName}</title><style>${css}</style></head><body><nav><a href="privacidad.html">Privacidad</a><a href="terminos.html">Términos</a><a href="contacto.html">Contacto</a></nav>${Legal.page(k)}</body></html>`);
console.log('✔ legal/*.html');
/* 2. Carpeta www/ */
const out = path.join(ROOT, 'www'); fs.rmSync(out, { recursive: true, force: true });
const cp = (s, d) => { fs.mkdirSync(path.dirname(path.join(out, d)), { recursive: true }); fs.copyFileSync(path.join(ROOT, s), path.join(out, d)); };
['index.html', 'config.js', 'manifest.webmanifest', 'sw.js'].forEach(f => cp(f, f));
['css', 'js', 'content', 'icons', 'fonts', 'legal'].forEach(d => fs.readdirSync(path.join(ROOT, d)).filter(f => !f.startsWith('_') && !fs.statSync(path.join(ROOT, d, f)).isDirectory()).forEach(f => cp(d + '/' + f, d + '/' + f)));
console.log('✔ www/ (' + fs.readdirSync(out).length + ' elementos)');
/* 3. Vista previa en un solo archivo */
const b64 = f => fs.readFileSync(path.join(ROOT, f)).toString('base64');
let html = rd('index.html'); let cssTxt = rd('css/app.css').replace(/url\(\.\.\/fonts\/([^)]+)\)/g, (m, f) => `url(data:font/woff2;base64,${b64('fonts/' + f)})`);
html = html.replace(/<link rel="stylesheet" href="css\/app.css">/, () => '<style>' + cssTxt + '</style>').replace(/<link rel="manifest"[^>]*>\n?/, '').replace(/<link rel="(icon|apple-touch-icon)"[^>]*>\n?/g, '');
html = html.replace(/<script src="([^"]+)"><\/script>/g, (m, s) => '<script>' + rd(s).replace(/<\/script>/gi, '<\\/script>') + '</script>');
const imgs = { 'icons/logo-512.png': 1, 'icons/avatar.png': 1 }; html = html.replace(/<script>/, '<script>window.__IMG=' + JSON.stringify(Object.fromEntries(Object.keys(imgs).map(k => [k, 'data:image/png;base64,' + b64(k)]))) + ';</script><script>'); // referencias
const tail = '<script>(function(){var M=window.__IMG;function f(){document.querySelectorAll("img").forEach(function(i){var s=i.getAttribute("src");if(M[s])i.src=M[s]})}new MutationObserver(f).observe(document.body,{childList:true,subtree:true});f()})();</script>';
const bi = html.lastIndexOf('</body>'); html = html.slice(0, bi) + tail + html.slice(bi);
html = html.replace(/<script>window\.__IMG=/, '<script>window.__IMG=');
fs.mkdirSync(path.join(ROOT, 'dist'), { recursive: true }); fs.writeFileSync(path.join(ROOT, 'dist', 'preview.html'), html);
console.log('✔ dist/preview.html (' + Math.round(html.length / 1024) + ' KB)');
