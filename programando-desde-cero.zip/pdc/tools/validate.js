#!/usr/bin/env node
/* Validador de contenido: node tools/validate.js content/world1.js [...] | --example | (sin args = todos)
   Revisa la estructura (ver tools/SCHEMA.md) y EJECUTA las soluciones con el mismo calificador de la app. */
const fs = require('fs'), path = require('path'), vm = require('vm');
const ROOT = path.join(__dirname, '..');
const Grader = require(path.join(ROOT, 'js/grader.js'));
const Runners = require(path.join(ROOT, 'js/runners.js'));
const PyRun = require(path.join(ROOT, 'js/pyrun.js'));
let JSDOM; try { JSDOM = require('jsdom').JSDOM; } catch (e) { console.log('⚠ jsdom no instalado: no se validarán html/css'); }
let args = process.argv.slice(2); const example = args.includes('--example'); args = args.filter(a => a !== '--example');
let files = args.length ? args : (example ? ['content/_ejemplo.js'] : fs.readdirSync(path.join(ROOT, 'content')).filter(f => /\.js$/.test(f) && !f.startsWith('_')).map(f => 'content/' + f));
const errors = [], warns = []; const E = (w, m) => errors.push(w + ': ' + m), W = (w, m) => warns.push(w + ': ' + m);
const str = v => typeof v === 'string' && v.trim().length > 0;
const STATIC = ['mcq', 'tf', 'multi', 'input', 'order', 'fill', 'match', 'bug'];
const BLOCKS = ['p', 'analogy', 'list', 'steps', 'tip', 'warn', 'code', 'table', 'vocab', 'dialog', 'flow'];
const LANGS = ['python', 'js', 'html', 'css', 'sql', 'pseudo'];
const ctx = {
  runJS: (c, i) => Runners.runJS(c, i),
  settle: () => new Promise(r => setTimeout(r, 25)),
  renderHTML: async (code, ex) => { const dom = new JSDOM(Grader.buildPage(code, ex), { runScripts: 'dangerously', pretendToBeVisual: true }); await new Promise(r => setTimeout(r, 25)); return { doc: dom.window.document, win: dom.window, cleanup: () => dom.window.close() }; }
};
function regexes(w, arr) { (arr || []).forEach(c => { try { new RegExp(c.re, 'i'); } catch (e) { E(w, 'regex inválida ' + c.re); } if (!str(c.msg)) W(w, 'check sin msg: ' + c.re); }); }
async function exercise(w, e, inExam) {
  if (!e || typeof e !== 'object') return E(w, 'ejercicio inválido');
  const type = e.type;
  if (!STATIC.includes(type) && type !== 'code') return E(w, 'type desconocido: ' + type);
  if (!str(e.q)) E(w, 'falta q'); if (!str(e.explain)) E(w, 'falta explain');
  if (e.hints !== undefined && (!Array.isArray(e.hints) || e.hints.length > 3 || e.hints.some(h => !str(h)))) E(w, 'hints: array de 1-3 textos');
  if (!inExam && type !== 'tf' && type !== 'multi' && !e.hints) W(w, 'sin hints');
  if (type === 'mcq') {
    if (!Array.isArray(e.options) || e.options.length < 3 || e.options.length > 5) E(w, 'mcq: 3-5 opciones');
    else { if (!Number.isInteger(e.answer) || e.answer < 0 || e.answer >= e.options.length) E(w, 'mcq: answer fuera de rango'); if (new Set(e.options).size !== e.options.length) E(w, 'opciones repetidas'); if (e.options.some(o => /(todas|ninguna) (de )?las anteriores/i.test(o))) E(w, 'nada de "todas/ninguna de las anteriores"'); if (!inExam && !e.wrong) W(w, 'mcq sin wrong'); if (e.wrong) Object.keys(e.wrong).forEach(k => { if (+k === e.answer || !(+k in e.options)) E(w, 'wrong con índice inválido ' + k); }); }
  } else if (type === 'tf') { if (typeof e.answer !== 'boolean') E(w, 'tf: answer boolean'); }
  else if (type === 'multi') { if (!Array.isArray(e.options) || e.options.length < 4) E(w, 'multi: ≥4 opciones'); else if (!Array.isArray(e.answers) || e.answers.length < 2 || e.answers.some(a => !Number.isInteger(a) || a < 0 || a >= e.options.length)) E(w, 'multi: answers ≥2 índices válidos'); }
  else if (type === 'input') { if (!Array.isArray(e.answers) || !e.answers.length) E(w, 'input: answers'); else if (!e.answers.some(a => Grader.gradeStatic(e, a).ok)) E(w, 'input: ninguna answer se acepta a sí misma'); regexes(w, e.common); if (e.common) e.common.forEach(c => { if (e.answers && e.answers.some(a => new RegExp(c.re, 'i').test(String(a)))) E(w, 'common coincide con una respuesta correcta: ' + c.re); }); }
  else if (type === 'order') { if (!Array.isArray(e.items) || e.items.length < 3 || e.items.length > 8 || new Set(e.items).size !== e.items.length) E(w, 'order: 3-8 items únicos'); }
  else if (type === 'fill') { const n = (String(e.template || '').match(/___/g) || []).length; if (!n) E(w, 'fill: template sin ___'); else if (!Array.isArray(e.blanks) || e.blanks.length !== n) E(w, 'fill: blanks (' + (e.blanks || []).length + ') != ___ (' + n + ')'); else e.blanks.forEach((b, i) => { if (!b || !Array.isArray(b.answers) || !b.answers.length) E(w, 'blank ' + i + ' sin answers'); else if (b.options && !b.answers.some(a => b.options.includes(a))) E(w, 'blank ' + i + ': al menos una answer debe estar en options'); }); }
  else if (type === 'match') { if (!Array.isArray(e.pairs) || e.pairs.length < 3 || e.pairs.length > 6 || e.pairs.some(p => !Array.isArray(p) || p.length !== 2)) E(w, 'match: 3-6 pares'); else if (new Set(e.pairs.map(p => p[1])).size !== e.pairs.length) E(w, 'match: derechas repetidas'); }
  else if (type === 'bug') { if (!str(e.code)) E(w, 'bug: falta code'); else if (!Number.isInteger(e.bugLine) || e.bugLine < 1 || e.bugLine > e.code.split('\n').length) E(w, 'bug: bugLine fuera de rango'); }
  else if (type === 'code') {
    if (!LANGS.includes(e.lang)) return E(w, 'lang inválido ' + e.lang);
    if (!str(e.solution)) return E(w, 'code: falta solution'); if (typeof e.starter !== 'string') E(w, 'code: falta starter');
    regexes(w, e.checks); regexes(w, e.common);
    if ((e.lang === 'python' || e.lang === 'js')) { if (!e.tests || !e.tests.length) E(w, 'code: faltan tests'); else if (e.tests.length < 2) W(w, 'usa ≥2 tests'); }
    if (e.lang === 'sql' && (!e.db || !(e.expect || e.expectTable))) E(w, 'sql: faltan db y expect/expectTable');
    if ((e.lang === 'html' || e.lang === 'css') && (!e.domChecks || !e.domChecks.length)) E(w, e.lang + ': faltan domChecks');
    if (e.lang === 'css' && !str(e.html)) E(w, 'css: falta html');
    if (e.lang === 'pseudo' && (!e.checks || e.checks.length < 2)) E(w, 'pseudo: ≥2 checks');
    if ((e.lang === 'html' || e.lang === 'css') && !JSDOM) return;
    try {
      const r = await Grader.gradeCode(e, e.solution, ctx);
      if (!r.ok) E(w, 'LA SOLUCIÓN NO PASA: ' + JSON.stringify({ checks: r.failedChecks, dom: r.domFails, tests: r.tests.filter(t => !t.ok).map(t => ({ in: t.inputs, exp: t.expected, got: t.got, err: t.error && t.error.message })), sql: r.sql && !r.sql.ok ? r.sql : undefined, err: r.error && r.error.message }).slice(0, 600));
      const s = await Grader.gradeCode(e, e.starter || '', ctx);
      if (s.ok) E(w, 'el starter ya pasa todas las pruebas');
    } catch (x) { E(w, 'excepción al calificar: ' + x.message); }
  }
}
function block(w, b) {
  if (!b || !BLOCKS.includes(b.t)) return E(w, 'bloque desconocido ' + (b && b.t));
  if (['p', 'analogy', 'tip', 'warn'].includes(b.t) && !str(b.text)) E(w, 'bloque ' + b.t + ' sin text');
  if (['list', 'steps'].includes(b.t) && (!Array.isArray(b.items) || !b.items.length)) E(w, b.t + ' sin items');
  if (b.t === 'code') { if (!str(b.code) || !LANGS.concat(['text']).includes(b.lang)) E(w, 'code block inválido'); else if (b.run && b.lang === 'python') { const r = PyRun.run(b.code, { inputs: String(b.inputs || '').split('\n') }); if (r.error) E(w, 'bloque python con run da error: ' + r.error.type + ': ' + r.error.message + ' @' + r.error.line); } }
  if (b.t === 'table' && (!Array.isArray(b.head) || !Array.isArray(b.rows) || b.rows.some(r => r.length !== b.head.length))) E(w, 'table: filas con distinta cantidad de columnas que head');
  if (b.t === 'vocab' && (!Array.isArray(b.items) || b.items.some(i => !str(i.en) || !str(i.es)))) E(w, 'vocab: items {en, es, ex}');
  if (b.t === 'dialog' && (!Array.isArray(b.lines) || b.lines.some(l => !str(l.who) || !str(l.en) || !str(l.es)))) E(w, 'dialog: lines {who,en,es}');
  if (b.t === 'flow' && (!Array.isArray(b.steps) || b.steps.some(s => !['start', 'end', 'io', 'process', 'decision'].includes(s.shape) || !str(s.text)))) E(w, 'flow: shapes inválidos');
}
(async () => {
  let nL = 0, nX = 0, nW = 0; const ids = new Set();
  for (const f of files) {
    const fp = path.isAbsolute(f) ? f : path.join(ROOT, f); const worlds = [];
    try { vm.runInNewContext(fs.readFileSync(fp, 'utf8'), { registerWorld: w => worlds.push(w) }, { filename: fp }); } catch (x) { E(f, 'no carga: ' + x.message); continue; }
    if (!worlds.length) E(f, 'no llamó a registerWorld');
    for (const Wd of worlds) {
      nW++; const wn = Wd.id || f;
      ['id', 'title', 'subtitle', 'emoji', 'color', 'intro'].forEach(k => { if (!str(Wd[k])) E(wn, 'falta ' + k); }); if (typeof Wd.n !== 'number') E(wn, 'falta n');
      if (!Wd.badge || !str(Wd.badge.name) || !str(Wd.badge.emoji)) E(wn, 'falta badge'); if (!/^#[0-9a-f]{6}$/i.test(Wd.color || '')) E(wn, 'color hex');
      if (!Array.isArray(Wd.lessons) || !Wd.lessons.length) { E(wn, 'sin lecciones'); continue; }
      const lids = Wd.lessons.map(l => l.id);
      for (let i = 0; i < Wd.lessons.length; i++) {
        const L = Wd.lessons[i], ln = wn + '/' + (L.id || '#' + (i + 1)); nL++;
        if (L.id !== Wd.id + '-l' + (i + 1)) E(ln, 'id esperado ' + Wd.id + '-l' + (i + 1)); if (ids.has(L.id)) E(ln, 'id duplicado'); ids.add(L.id);
        if (!str(L.title) || !str(L.emoji) || !(L.minutes > 0)) E(ln, 'falta title/emoji/minutes');
        if (!Array.isArray(L.learn) || L.learn.length < 3 || L.learn.length > 4) E(ln, 'learn: 3-4 tarjetas'); else L.learn.forEach((c, j) => { if (!str(c.title) || !Array.isArray(c.blocks) || c.blocks.length < 2) E(ln, 'learn[' + j + '] necesita title y ≥2 blocks'); else c.blocks.forEach(b => block(ln + '.learn[' + j + ']', b)); });
        const x = L.example; if (!x || !str(x.title) || !str(x.story)) E(ln, 'example: title y story'); else if (x.code) block(ln + '.example', Object.assign({ t: 'code' }, x.code));
        if (!Array.isArray(L.practice) || L.practice.length !== 3) E(ln, 'practice: exactamente 3'); else for (let j = 0; j < 3; j++) { nX++; await exercise(ln + '.p' + (j + 1), L.practice[j]); }
        if (!L.challenge || !/^🎯 Misión: /.test(L.challenge.q || '')) E(ln, 'challenge.q debe empezar con "🎯 Misión: "'); else { nX++; await exercise(ln + '.reto', L.challenge); }
        if (!Array.isArray(L.summary) || L.summary.length < 3) E(ln, 'summary ≥3');
        const types = new Set([...(L.practice || []), L.challenge].filter(Boolean).map(e => e.type)); if (types.size < 3) E(ln, 'necesita ≥3 tipos distintos de ejercicio (tiene ' + types.size + ')');
      }
      if (!example) {
        if (!Array.isArray(Wd.exam) || Wd.exam.length < 8 || Wd.exam.length > 10) E(wn, 'exam: 8-10 preguntas'); else { let nc = 0; for (let j = 0; j < Wd.exam.length; j++) { const q = Wd.exam[j]; if (q.type === 'code') nc++; if (!lids.includes(q.lesson)) E(wn + '.exam[' + j + ']', 'lesson inválida: ' + q.lesson); nX++; await exercise(wn + '.exam[' + j + ']', q, true); } if (nC(nc)) E(wn, 'máx 2 ejercicios code en el examen'); const cov = new Set(Wd.exam.map(q => q.lesson)); if (cov.size < Math.min(lids.length, Wd.exam.length) * 0.7) W(wn, 'el examen cubre solo ' + cov.size + ' de ' + lids.length + ' lecciones'); }
      }
    }
  }
  function nC(n) { return n > 2; }
  console.log(`${files.length} archivo(s) · ${nW} mundo(s) · ${nL} lecciones · ${nX} ejercicios ejecutados`);
  if (warns.length) { console.log('\nAVISOS (' + warns.length + '):'); warns.slice(0, 40).forEach(w => console.log(' ⚠ ' + w)); }
  if (errors.length) { console.log('\n❌ ' + errors.length + ' PROBLEMAS:'); errors.slice(0, 60).forEach(e => console.log(' - ' + e)); process.exit(1); }
  console.log('\n✅ Contenido válido.');
})();
